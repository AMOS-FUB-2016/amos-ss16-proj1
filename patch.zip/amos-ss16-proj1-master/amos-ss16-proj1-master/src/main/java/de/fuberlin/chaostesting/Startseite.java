package de.fuberlin.chaostesting;

import de.fuberlin.chaostesting.hibernate.Test;

public class Startseite {
    
    public String sayHello() {

    	String hw = new String("Hello World from Chaos Testing!</br>");
    	hw += "<a href=\"newAdmin.jsp\">Add Admin</a></br>";
    	hw += "<a href=\"newTester.jsp\">Add Tester</a></br>";
    	hw += "<a href=\"showUsers.jsp\">Show Users</a>";
        return hw;
    }
    
}